from django.apps import AppConfig


class ClockConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'clock'
