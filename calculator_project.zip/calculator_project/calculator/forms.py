from django import forms

class CalculatorForm(forms.Form):
   num1 = forms.DecimalField(label='Number 1')
   num2 = forms.DecimalField(label='Number 2')
   operation = forms.ChoiceField(label='Operation', 
choices=[
        ('+', 'Addition'),
        ('-', 'Subtraction'),
        ('*', 'Multiplication'),
        ('/', 'Division'),
  ])