import requests
from django.shortcuts import render
from .forms import CityForm

def index(request):
    form = CityForm()
    data = None
    error = None

    if request.method == 'POST':
        form = CityForm(request.POST)
        if form.is_valid():
            city = form.cleaned_data['city']
            api_key = "a9b0b2e31ef3503cf051079ee32267ec"
            url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
            resp = requests.get(url).json()

            if resp.get("cod") != 200:
                error = resp.get("message", "Error fetching weather")
            else:
                data = {
                    'city': city.title(),
                    'temp': resp['main']['temp'],
                    'desc': resp['weather'][0]['description'].title(),
                    'icon': resp['weather'][0]['icon'],
                }

    return render(request, 'index.html', {
        'form': form, 'weather': data, 'error': error
    })
